# HRMS Backend

## Setup
```
npm install
cp .env.example .env   # fill in DATABASE_URL + JWT_SECRET
npx prisma migrate dev --name init
npm run dev
```
You should see: `Server on port 5000`. Keep this terminal open while testing —
closing it or letting the machine sleep will stop the server.

## Endpoints
- POST /auth/signup, /auth/login
- GET/PUT /profile/me, PUT /profile/:userId (admin)
- POST /attendance/checkin, /attendance/checkout/:id, GET /attendance/me, /attendance/all (admin)
- POST /leave/apply, GET /leave/me, /leave/all (admin), PUT /leave/:id/review (admin)
- GET /payroll/me, /payroll/all (admin), PUT /payroll/:userId (admin)

All routes except signup/login need header: `Authorization: Bearer <token>`

## Troubleshooting
- **"Failed to fetch" in the frontend** -> the backend isn't reachable. Confirm
  `http://localhost:5000` shows "HRMS API running" in your browser. If not,
  the server isn't running -- check this terminal for errors.
- **Server crashes on a bad request** -> fixed: route errors are now caught and
  returned as a normal `500` JSON response instead of killing the process.
- **Prisma can't connect** -> double check `DATABASE_URL` in `.env` and that
  Postgres is actually running (`pg_isready` or check your hosted DB dashboard).
- **CORS errors** -> already enabled (`app.use(cors())`), shouldn't happen
  unless you changed ports without updating the frontend's `API` constant.
