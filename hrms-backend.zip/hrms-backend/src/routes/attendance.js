const router = require('express').Router();
const prisma = require('../prisma');
const { auth, requireRole } = require('../middleware/auth');

router.post('/checkin', auth, async (req, res) => {
  const record = await prisma.attendance.create({
    data: { userId: req.user.id, status: 'PRESENT', checkIn: new Date() }
  });
  res.json(record);
});

router.post('/checkout/:id', auth, async (req, res) => {
  const record = await prisma.attendance.update({
    where: { id: Number(req.params.id) },
    data: { checkOut: new Date() }
  });
  res.json(record);
});

router.get('/me', auth, async (req, res) => {
  const records = await prisma.attendance.findMany({ where: { userId: req.user.id } });
  res.json(records);
});

// Admin: view all
router.get('/all', auth, requireRole('ADMIN'), async (req, res) => {
  const records = await prisma.attendance.findMany({ include: { user: true } });
  res.json(records);
});

module.exports = router;
