const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const prisma = require('../prisma');

router.post('/signup', async (req, res) => {
  const { employeeId, email, password, role } = req.body;
  const hash = await bcrypt.hash(password, 10);
  try {
    const user = await prisma.user.create({
      data: { employeeId, email, password: hash, role: role?.toUpperCase() || 'EMPLOYEE' }
    });
    // TODO: send real verification email
    res.json({ id: user.id, email: user.email });
  } catch (e) {
    res.status(400).json({ error: 'Signup failed (duplicate email/employeeId?)' });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, role: user.role, email: user.email } });
});

module.exports = router;
